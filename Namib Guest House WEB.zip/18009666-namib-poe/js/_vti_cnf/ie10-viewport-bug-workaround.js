vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Nov 2015 08:50:52 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|rates.html booking-enquiries.html contact-us.html gallery.html accommodation.html things-to-do.html facilities.html thank-you.html template.html index.html
vti_author:SR|BRENDONLAPTOP\\Brendon Hatcher
vti_modifiedby:SR|BRENDONLAPTOP\\Brendon Hatcher
vti_timecreated:TR|26 Nov 2015 08:50:52 -0000
vti_cacheddtm:TX|26 Nov 2015 08:50:52 -0000
vti_filesize:IR|641
